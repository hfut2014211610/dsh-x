/**
 * Document capability seam for writing mode.
 * @module @deepseek-ai/dsh-documents
 */
import { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { SessionId } from '@deepseek-ai/dsh-session';
import type { DocumentEdit, DocumentLocator, DocumentOutlineResult, DocumentReadResult, DocumentSearchResult } from './types.ts';
export { DocumentError } from './error.ts';
export type { DocumentErrorCode } from './error.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        documents: Documents;
    }
}
/** Document service (`ctx.documents`) shared by host providers and consumers. */
export declare abstract class Documents extends TypertRemoteService {
    constructor(ctx: Context);
    /** Resolve and read a whole document or a located slice. */
    read(request: {
        sessionId: SessionId;
        path: string;
        locator?: DocumentLocator;
    }): Promise<DocumentReadResult>;
    /** Read the structural outline of a document. */
    outline(request: {
        sessionId: SessionId;
        path: string;
    }): Promise<DocumentOutlineResult>;
    /** Search workspace documents by content keywords. */
    search(request: {
        sessionId: SessionId;
        query: string;
        limit?: number;
    }): Promise<DocumentSearchResult>;
    /** Create a new supported text document. */
    create(request: {
        sessionId: SessionId;
        path: string;
        content: string;
    }): Promise<{
        path: string;
        version: string;
    }>;
    /** Apply one version-guarded document mutation and emit documents/changed. */
    apply(request: {
        sessionId: SessionId;
        path: string;
        baseVersion: string;
        edit: DocumentEdit;
    }): Promise<{
        version: string;
    }>;
}
export default Documents;
//# sourceMappingURL=index.d.ts.map