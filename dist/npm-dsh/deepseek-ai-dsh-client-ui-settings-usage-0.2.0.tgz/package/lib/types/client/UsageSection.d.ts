/**
 * Model usage settings section, global view over a chosen statistics window:
 * a whole-list summary strip, a day-bucketed dot heatmap of consumption
 * intensity (each dot carries a hover tooltip with its day and buckets), and
 * one aggregate row per model. The panel is session-blind — the data is every
 * session's `usageStats` projection value joined through the session list,
 * read on open, on connection reset, and on demand; switching the window
 * re-aggregates the last good rows offline.
 */
import type { ReactNode } from 'react';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-web-react';
import type { UsageSettingsState, UsageSettingsStore } from './store.ts';
import type { DayUsage } from './view-model.ts';
import type { UsageKey } from './locales.ts';
/** Injected dependencies of {@link UsageSection} (slot `inject`). */
export interface UsageSectionInjected {
    /** The page store (loaded on mount, refreshed on demand). */
    controller: UsageSettingsStore;
    /** uSES subscription hook bound to the store. */
    useSnapshot: SnapshotSelectorHook<UsageSettingsState>;
    /** Section copy. */
    t: (key: UsageKey) => string;
}
/** Props delivered by the slot outlet: the inject face spread flat. */
export type UsageSectionProps = Partial<UsageSectionInjected>;
/**
 * The hover tooltip text of one heatmap cell: its day and that day's buckets,
 * or the day plus a no-usage notice when the cell is empty.
 * @param day - the day bucket.
 * @param t - section copy.
 * @returns the tooltip text.
 */
export declare function dayTooltip(day: DayUsage, t: UsageSectionInjected['t']): string;
/**
 * Render the usage section content column.
 * @param props - slot-delivered injected dependencies.
 * @returns the section, or null while the shell has not injected yet.
 */
export declare function UsageSection(props: UsageSectionProps): ReactNode;
//# sourceMappingURL=UsageSection.d.ts.map