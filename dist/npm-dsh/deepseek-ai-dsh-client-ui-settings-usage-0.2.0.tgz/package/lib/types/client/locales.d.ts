/**
 * Usage section copy, zh authoritative with an en mirror. One physical line
 * per entry; `{days}`/`{n}`/`{date}`/`{prompt}`/`{output}` placeholders are
 * replaced by `String.replace`.
 */
export declare const zh: {
    readonly nav: "用量";
    readonly title: "模型用量";
    readonly intro: "全部会话累计的模型 token 消耗。冷会话展示其最后一次持久化检查点的数据。";
    readonly refresh: "刷新";
    readonly rangeLabel: "统计区间";
    readonly range7: "7 天";
    readonly range28: "28 天";
    readonly range90: "90 天";
    readonly rangeAll: "全部";
    readonly statSessions: "会话";
    readonly statRequests: "请求";
    readonly statInput: "输入";
    readonly statCacheRead: "缓存读";
    readonly statCacheWrite: "缓存写";
    readonly statOutput: "输出";
    readonly statReasoning: "推理";
    readonly statLlmTime: "模型时长";
    readonly heatmapLabel: "每日 token 用量点阵图，颜色越深当日消耗越大";
    readonly heatmapCaption: "每日消耗点阵（按窗口内最忙一日分档着色，悬浮查看当日明细）。";
    readonly today: "今天";
    readonly yesterday: "昨天";
    readonly daysAgo: "{n} 天前";
    readonly noUsage: "无消耗";
    readonly tooltipDay: "{date} · 输入+缓存 {prompt} · 输出 {output}";
    readonly model: "模型";
    readonly empty: "所选区间内尚无模型用量记录。";
    readonly errorTitle: "加载失败";
};
export type UsageKey = keyof typeof zh;
export declare const en: Record<UsageKey, string>;
//# sourceMappingURL=locales.d.ts.map