/**
 * Usage settings page store: one snapshot joining the session list with each
 * row's `usageStats` projection value into the panel's view model. The host
 * stays the single fact source — the panel only reads, refreshing on open,
 * on connection reset, and on demand.
 */
import type { IApiClient } from '@deepseek-ai/dsh-api-remotes/client';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { UsageOverview } from './view-model.ts';
import type { UsageRange } from './view-model.ts';
/** Panel snapshot. */
export interface UsageSettingsState {
    status: 'idle' | 'loading' | 'ready' | 'error';
    /** Whole-load failure text. */
    error: string | null;
    /** The active statistics window. */
    range: UsageRange;
    /** The aggregated view model; empty until the first ready load. */
    overview: UsageOverview;
}
/** The usage settings page controller (one per settings surface). */
export declare class UsageSettingsStore {
    private readonly api;
    /** The snapshot the section renders from (uSES-safe store). */
    readonly store: SnapshotStore<UsageSettingsState>;
    /** Latest load wins; an older response never overwrites a newer one. */
    private generation;
    /** The last good wire rows; a range switch re-aggregates these offline. */
    private inputs;
    /**
     * @param api - the wire face (session-list domain).
     */
    constructor(api: Pick<IApiClient, 'sessions'>);
    /**
     * Refresh the whole panel snapshot from one session-list page. A failure
     * keeps the last good overview and surfaces the error.
     * @returns nothing; the snapshot carries the outcome.
     */
    load(): Promise<void>;
    /**
     * Switch the statistics window and re-aggregate the last good rows offline —
     * no wire traffic, no status change.
     * @param range - the window to aggregate over.
     */
    setRange(range: UsageRange): void;
}
//# sourceMappingURL=store.d.ts.map