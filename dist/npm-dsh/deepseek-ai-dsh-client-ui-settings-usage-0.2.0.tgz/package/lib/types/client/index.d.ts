/**
 * Usage settings plugin, browser half: registers the Model usage page — a
 * cross-session token-consumption panel over the session-list rows' usageStats
 * projection values. The Host stays the single fact source through the
 * session.list wire join; the page only reads.
 * Export discipline: packages/client/AGENTS.md.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { UsageSettingsStore } from './store.ts';
import type { UsageKey } from './locales.ts';
export type { UsageSectionInjected, UsageSectionProps } from './UsageSection.tsx';
export type { UsageSettingsState, UsageSettingsStore } from './store.ts';
export type { UsageKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The usage page copy. */
        'settings.usage': UsageKey;
    }
}
/**
 * Refetch the page snapshot only after its first load: an unopened usage
 * page must not fetch on background resets.
 * @param controller - the page store.
 */
export declare function refreshIfLoaded(controller: UsageSettingsStore): void;
/**
 * Required services (cordis fiber inject). The target slot is declared by
 * ui-settings' apply, whose activation order relative to this one is NOT
 * constrained; registration depends on each slot through `slots.inject()`.
 */
export declare const inject: string[];
/**
 * Register the usage section once the `settings.section` declaration is on
 * the ledger, wire its store to the connection, and refetch after a
 * connection reset (the projection rows ride the session list).
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map