/**
 * Pure aggregation of wire-delivered `usageStats` projection rows into the
 * settings panel's GLOBAL view model: whole-list totals, one row per model,
 * and a day-bucketed dot-heatmap series. The panel is session-blind by
 * design — sessions contribute their requests, never their identity. Missing
 * buckets stay `undefined`: an absent count is a reporting gap, not a
 * measured zero, and the panel renders it as `—`.
 *
 * @module @deepseek-ai/dsh-client-ui-settings-usage/view-model
 */
import type { UsageRequestRecord, UsageStatsProjection } from '@deepseek-ai/dsh-usage-stats/client';
/** One session-list row narrowed to what the panel aggregates. */
export interface UsageSessionInput {
    sessionId: string;
    /** Display title; the wire may not have one yet. */
    title: string | undefined;
    /** Later of creation and the latest human prompt, epoch ms. */
    updatedAt: number;
    /** The row's `usageStats` projection value; null when the row carries none. */
    usage: UsageStatsProjection | null;
}
/** Token and wall-time sums; optional buckets stay absent when unreported anywhere. */
export interface UsageTotals {
    requests: number;
    inputTokens: number;
    cacheReadTokens: number;
    cacheWriteTokens?: number;
    outputTokens: number;
    reasoningTokens?: number;
    llmMs: number;
}
/** One model's whole-list aggregate; a null model groups unreported routes. */
export interface ModelUsageRow extends UsageTotals {
    /** Model id the requests ran on; null when the route never landed in the log. */
    model: string | null;
}
/** One day bucket of the dot heatmap. */
export interface DayUsage {
    /** Days before the aggregation instant (0 = that day). */
    daysAgo: number;
    /** Summed prompt-side tokens (uncached input plus cache traffic) over the day's requests. */
    promptTokens: number;
    /** Summed output tokens over the day's requests. */
    outputTokens: number;
}
/** The whole panel's view model. */
export interface UsageOverview {
    totals: UsageTotals;
    /** Model aggregates, most requests first. */
    models: readonly ModelUsageRow[];
    /** Day buckets covering the newest {@link HEATMAP_WINDOW_DAYS} days, oldest first. */
    days: readonly DayUsage[];
    /** Largest day total inside the window (the heatmap's intensity scale). */
    maxDayTokens: number;
    /** Sessions contributing at least one request. */
    sessionsWithUsage: number;
}
/** Statistics windows the panel offers; 'all' aggregates the whole log. */
export type UsageRange = 7 | 28 | 90 | 'all';
export declare const USAGE_RANGES: readonly UsageRange[];
/** Days the dot heatmap covers at most, ending at the aggregation instant's day. */
export declare const HEATMAP_WINDOW_DAYS = 28;
/** Day cells a range draws: its own span, capped at the heatmap window. */
export declare const heatmapDaysOf: (range: UsageRange) => number;
/**
 * Aggregate every request into one row per model.
 * @param requests - every session's per-request records.
 * @returns model aggregates, most requests first.
 */
export declare function modelBreakdown(requests: readonly UsageRequestRecord[]): ModelUsageRow[];
/**
 * Bucket the requests into day cells covering the newest `windowDays` days
 * before `now`.
 * @param requests - every session's per-request records.
 * @param now - the aggregation instant, epoch ms.
 * @param windowDays - day cells to cover.
 * @returns day buckets oldest first, empty days included, each stamped with
 *   its distance in days from `now`'s day.
 */
export declare function dailyUsage(requests: readonly UsageRequestRecord[], now: number, windowDays: number): DayUsage[];
/**
 * Build the panel's whole global view model from the session-list rows.
 * @param inputs - every listed session narrowed to its usage facts.
 * @param now - the aggregation instant, epoch ms (default: the call time).
 * @param range - the statistics window (default: the last 28 days).
 * @returns totals, per-model aggregates, and the day heatmap series — all
 *   over the requests whose time falls inside the window.
 */
export declare function usageOverviewOf(inputs: readonly UsageSessionInput[], now?: number, range?: UsageRange): UsageOverview;
/**
 * Render one token count with k/M scaling.
 * @param tokens - the count to render.
 * @returns the compact count (`999`, `1.2k`, `3.4M`).
 */
export declare function formatTokens(tokens: number): string;
/**
 * Render one wall-time duration.
 * @param ms - the duration in milliseconds.
 * @returns the duration in ms, s, or m.
 */
export declare function formatDuration(ms: number): string;
/** Heatmap intensity grades: 0 is an empty day, 1–4 fill quadrants of the scale. */
export declare const MAX_INTENSITY = 4;
/**
 * Heatmap intensity grade of one day against the window maximum.
 * @param day - the day bucket.
 * @param maxDayTokens - the window's largest day total.
 * @returns 0 for an empty day, otherwise 1–4 in quadrants of the maximum.
 */
export declare function intensityOf(day: DayUsage, maxDayTokens: number): number;
//# sourceMappingURL=view-model.d.ts.map