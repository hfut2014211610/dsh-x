/**
 * Locale dictionaries for the writing view.
 * @module @deepseek-ai/dsh-client-ui-writing/locales
 */
/** Dictionary namespace owned by this plugin. */
export declare const NS = "ui-writing";
/** The writing dictionary key set (the source of truth for both locales). */
export type WritingKey = 'view.writing' | 'placeholder';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The writing view tab label and placeholder. */
        'ui-writing': WritingKey;
    }
}
/** Simplified Chinese dictionary. */
export declare const zh: Record<WritingKey, string>;
/** English dictionary. */
export declare const en: Record<WritingKey, string>;
//# sourceMappingURL=locales.d.ts.map