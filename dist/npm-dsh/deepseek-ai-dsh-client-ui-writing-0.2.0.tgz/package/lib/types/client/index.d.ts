/**
 * Browser writing-mode plugin.
 * @module @deepseek-ai/dsh-client-ui-writing/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required services: the conversation slot, conversation service, sessions, remote, and locale. */
export declare const inject: string[];
/**
 * Client plugin body: register the writing view tab, declare it as the
 * preferred view for `writing` sessions, and supply the documents Remote
 * callbacks to the view.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map