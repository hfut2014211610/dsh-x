/**
 * Writing view for Phase 1.
 * @module @deepseek-ai/dsh-client-ui-writing/WritingView
 */
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { DocumentReadResult } from '@deepseek-ai/dsh-documents/types';
/** Injected document actions supplied by the writing plugin. */
export interface WritingViewInjected {
    load: (path: string) => Promise<DocumentReadResult | {
        error: string;
    }>;
    save: (path: string, baseVersion: string, content: string) => Promise<{
        version: string;
    } | {
        error: string;
    }>;
    outline: (path: string) => Promise<readonly {
        id: string;
        kind: string;
        title: string;
    }[]>;
    search: (query: string) => Promise<readonly {
        path: string;
        title: string;
        snippet: string;
    }[]>;
    subscribeChanged: (fn: () => void) => () => void;
}
/**
 * Phase 1 writing surface: a textarea editor backed by the documents Remote,
 * with a simple search overlay and outline rail.
 */
export declare function WritingView({ sessionId, useSessions, load, save, outline, search, subscribeChanged }: ConvViewProps & WritingViewInjected): import("react").JSX.Element;
//# sourceMappingURL=WritingView.d.ts.map