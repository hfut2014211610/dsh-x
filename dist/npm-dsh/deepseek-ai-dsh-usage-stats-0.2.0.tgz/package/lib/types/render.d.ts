/**
 * Pure Markdown rendering of the `usageStats` projection: a summary table, a
 * fenced per-turn heatmap whose bars scale to this session's maxima, and a
 * per-request detail table. The output is plain GFM (tables plus one fenced
 * block), so every dispatching UI renders it without a dedicated card.
 * Missing buckets render as `—`, never as 0: an absent count is a reporting
 * gap, not a measured zero.
 *
 * @module @deepseek-ai/dsh-usage-stats/render
 */
import type { UsageStatsProjection } from './types.ts';
/**
 * Render the whole usage report for one session.
 * @param value - the `usageStats` projection value.
 * @returns the Markdown report: summary table, per-turn heatmap, per-request
 *   detail table; a one-line notice when no request reported usage yet.
 */
export declare function renderUsageReport(value: UsageStatsProjection): string;
//# sourceMappingURL=render.d.ts.map