/**
 * The `usageStats` projection unit: a pure fold of request routes, step
 * boundaries, and logged usage reports into one record per model request.
 *
 * A record exists for every step that reported usage or assembled a message.
 * `assistant/chunk` usage reports create or update the step's record early —
 * so a request that failed after streaming usage stays billed — and the
 * `assistant/message` settles the same record with the final usage and the
 * model wall time (`step/start` → message, the same boundary session-stats
 * sums as `llmMs`). The single-record-per-step upsert relies on the log
 * invariant token-meter also relies on: usage reports for one turn/step are
 * adjacent, so checking the last record decides match-vs-append. Provider and
 * model ride the latest `request/context` (logged only on route or capacity
 * change), which is the request the step actually dispatched on.
 *
 * @module @deepseek-ai/dsh-usage-stats/projection
 */
import type { TokenUsage } from '@deepseek-ai/dsh-llm';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
/** Fold-state twin of {@link UsageRequestRecord}; fields stay writable until the record settles. */
interface MutableUsageRequestRecord {
    turn: number;
    step: number;
    time: number;
    provider: string | null;
    model: string | null;
    usage: TokenUsage | null;
    llmMs: number | null;
}
/**
 * Fold state: the records plus the routing and boundary facts they accrue
 * from. Plain JSON per the unit contract (persisted-cache precondition).
 */
interface UsageStatsState {
    requests: MutableUsageRequestRecord[];
    /** The open step's start facts; null outside a step or after its message assembled. */
    openStep: {
        turn: number;
        step: number;
        startTime: number;
    } | null;
    /** Route of the latest `request/context`; null before the first. */
    provider: string | null;
    model: string | null;
    /** Advertised context window of the latest `request/context`; null when never advertised. */
    contextWindow: number | null;
}
/** The `usageStats` unit registered on `ctx.sessionProjections` (exported for the unit spec). */
export declare const usageStatsProjectionDefinition: ProjectionDefinition<'usageStats', UsageStatsState>;
export {};
//# sourceMappingURL=projection.d.ts.map