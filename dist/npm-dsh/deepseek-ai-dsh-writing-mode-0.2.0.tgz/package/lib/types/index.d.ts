/**
 * Writing-mode system-prompt section.
 * @module @deepseek-ai/dsh-writing-mode
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "writing-mode";
export declare const inject: string[];
/** Register the writing:policy system-prompt section. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map