/**
 * Local workspace document provider for writing mode.
 * @module @deepseek-ai/dsh-documents-local
 */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { Documents } from '@deepseek-ai/dsh-documents';
import type { DocumentEdit, DocumentLocator, DocumentOutlineResult, DocumentReadResult, DocumentSearchResult } from '@deepseek-ai/dsh-documents';
import type { SessionId } from '@deepseek-ai/dsh-session';
/** Configuration for the local documents provider. */
export interface Config {
    root: string;
    maxReadChars?: number;
    maxOutlineItems?: number;
    maxSearchFiles?: number;
}
export interface ResolvedConfig {
    root: string;
    maxReadChars: number;
    maxOutlineItems: number;
    maxSearchFiles: number;
}
export declare class DocumentsLocal extends Documents {
    static Config: z<Config>;
    private readonly resolved;
    constructor(ctx: Context, config: Config);
    private formatOf;
    private resolveWorkspaceTarget;
    private resolveDocument;
    read(request: {
        sessionId: SessionId;
        path: string;
        locator?: DocumentLocator;
    }): Promise<DocumentReadResult>;
    outline(request: {
        sessionId: SessionId;
        path: string;
    }): Promise<DocumentOutlineResult>;
    search(request: {
        sessionId: SessionId;
        query: string;
        limit?: number;
    }): Promise<DocumentSearchResult>;
    create(request: {
        sessionId: SessionId;
        path: string;
        content: string;
    }): Promise<{
        path: string;
        version: string;
    }>;
    apply(request: {
        sessionId: SessionId;
        path: string;
        baseVersion: string;
        edit: DocumentEdit;
    }): Promise<{
        version: string;
    }>;
}
export default DocumentsLocal;
//# sourceMappingURL=index.d.ts.map