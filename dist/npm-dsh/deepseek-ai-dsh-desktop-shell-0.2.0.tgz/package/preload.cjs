// Loading-screen bridge: the sandboxed, context-isolated renderer gets exactly
// the shell capabilities it needs — observing snapshots, retrying, and
// driving in-app updates. No node integration, no arbitrary IPC:
// contextBridge freezes this surface.
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('dshDesktopShell', {
  onState: (listener) => {
    const handler = (_event, state) => { listener(state) }
    ipcRenderer.on('dsh-desktop-shell:state', handler)
    return () => { ipcRenderer.removeListener('dsh-desktop-shell:state', handler) }
  },
  retry: () => { ipcRenderer.send('dsh-desktop-shell:retry') },
  checkForUpdates: () => ipcRenderer.invoke('dsh-desktop-shell:update-check'),
  downloadUpdate: () => ipcRenderer.invoke('dsh-desktop-shell:update-download'),
  quitAndInstall: () => ipcRenderer.invoke('dsh-desktop-shell:update-install'),
  onUpdateStatus: (listener) => {
    const handler = (_event, status) => { listener(status) }
    ipcRenderer.on('dsh-desktop-shell:update-status', handler)
    return () => { ipcRenderer.removeListener('dsh-desktop-shell:update-status', handler) }
  },
})
