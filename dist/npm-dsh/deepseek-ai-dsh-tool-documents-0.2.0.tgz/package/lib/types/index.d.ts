/**
 * Model-facing document tools for writing mode.
 * @module @deepseek-ai/dsh-tool-documents
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "tool-documents";
export declare const inject: string[];
/** Register the five document_* tools. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map